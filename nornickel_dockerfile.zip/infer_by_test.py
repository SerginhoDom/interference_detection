import os
import sys
import json
import base64
import cv2
import numpy as np
import onnxruntime as ort  # Добавлен импорт onnxruntime
from torchvision import transforms
from PIL import Image

# Проверка количества аргументов
if len(sys.argv) != 3:
    sys.exit("Usage: python infer_by_test_onnx.py <dataset_path> <output_path>")

# Получение путей из аргументов командной строки
dataset_path, output_path = sys.argv[1], sys.argv[2]
model_weights_path = './deeplabv3_plus_model.onnx'  # Путь к файлу модели ONNX

# Проверка существования файла модели
if not os.path.exists(model_weights_path):
    sys.exit(f"Файл модели ONNX не найден: {model_weights_path}")

# Инициализация сессии ONNX Runtime
try:
    ort_session = ort.InferenceSession(model_weights_path)
except Exception as e:
    sys.exit(f"Ошибка инициализации ONNX Runtime: {e}")

# Трансформации для входных изображений
transform = transforms.Compose([
    transforms.Resize((256, 256)),  # Размер, соответствующий обучению модели
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406],  # Средние значения для ImageNet
                         std=[0.229, 0.224, 0.225]),   # Стандартные отклонения для ImageNet
])

def infer_image_onnx(ort_session, image_path, transform):
    """
    Выполняет инференс на одном изображении с использованием ONNX модели.
    """
    # Загружаем изображение с помощью OpenCV
    image = cv2.imread(image_path)
    if image is None:
        return None  # Возвращаем None, если изображение не удалось загрузить
    
    # Преобразуем изображение из BGR в RGB
    image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    image_pil = Image.fromarray(image_rgb)
    
    # Применяем трансформации
    image_transformed = transform(image_pil).unsqueeze(0).numpy()  # Добавляем размерность батча и преобразуем в numpy
    
    # Прогоняем изображение через модель
    try:
        ort_inputs = {ort_session.get_inputs()[0].name: image_transformed}
        ort_outs = ort_session.run(None, ort_inputs)
        output = ort_outs[0]  # Предполагается, что выход модели - это [batch_size, num_classes, H, W]
    except Exception as e:
        print(f"Ошибка инференса для изображения {image_path}: {e}")
        return None
    
    # Получаем метки классов
    output_mask = np.argmax(output, axis=1)[0]  # Берём первый элемент в батче
    return output_mask

def create_mask(image_path, output_mask):
    """
    Создаёт маску с оригинальными размерами изображения.
    """
    # Загружаем изображение и его размеры
    image = cv2.imread(image_path)
    if image is None:
        return None  # Возвращаем None, если изображение не удалось загрузить
    height, width = image.shape[:2]
    
    # Ресайз маски до размеров исходного изображения
    mask_resized = cv2.resize(output_mask.astype(np.uint8), (width, height), interpolation=cv2.INTER_NEAREST)
    mask = np.zeros((height, width), dtype=np.uint8)
    mask[mask_resized == 1] = 255  # Применяем маску (1 - объект, 0 - фон)
    
    return mask

def process_images_onnx(ort_session, dataset_path, output_path, transform):
    """
    Выполняет инференс для всех изображений в указанном датасете и сохраняет результаты в JSON файл.
    """
    results_dict = {}
    
    for image_name in os.listdir(dataset_path):
        if image_name.lower().endswith((".jpg", ".jpeg", ".png")):  # Поддержка нескольких форматов
            image_path = os.path.join(dataset_path, image_name)
            output_mask = infer_image_onnx(ort_session, image_path, transform)
            if output_mask is None:
                continue  # Пропускаем, если изображение не удалось обработать
            mask = create_mask(image_path, output_mask)
            if mask is None:
                continue  # Пропускаем, если маску не удалось создать
            # Кодируем маску в PNG
            success, encoded_img = cv2.imencode(".png", mask)
            if not success:
                continue  # Пропускаем, если кодирование не удалось
            # Кодируем в base64 для JSON
            encoded_str = base64.b64encode(encoded_img).decode('utf-8')
            results_dict[image_name] = encoded_str
    
    # Сохраняем результаты в JSON файл
    try:
        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(results_dict, f, ensure_ascii=False)
        print(f"Результаты инференса сохранены в {output_path}")
    except Exception as e:
        sys.exit(f"Ошибка сохранения JSON файла: {e}")

# Обработка изображений и сохранение результатов
process_images_onnx(ort_session, dataset_path, output_path, transform)